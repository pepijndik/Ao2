# PHP AdminPanel

een admin panel voor SimpelShop. opdracht PHP Periode 1.

## Hoe te installeren?

1. Pull Repo
2. Zet de Repo in je Htdocs(/var/www)

Importeer SQL.txt (Verander txt naar .SQL)

Default Gebruikers naam en wachtwoord: Pepijn, pep

```bash
Functions/Database/SQL.txt
```

```bash
Username | Password
Pepijn   | Pep
```

## Needed

```Gebruik
MYSQL, Apache2, PHPMyAdmin

```

## Contributing

## License

[MIT,PDIK](https://pdik.nl/)
